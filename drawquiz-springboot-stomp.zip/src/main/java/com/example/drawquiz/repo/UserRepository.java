package com.example.drawquiz.repo;

import com.example.drawquiz.domain.UserEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserEntity, Long> {
    Optional<UserEntity> findByName(String name);
    boolean existsByName(String name);
    List<UserEntity> findByNameIn(Collection<String> names);
}
