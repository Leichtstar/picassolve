package com.example.drawquiz.repo;

import com.example.drawquiz.domain.WordEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WordRepository extends JpaRepository<WordEntity, Long> { }
