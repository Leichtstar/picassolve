package com.example.drawquiz.controller;

import com.example.drawquiz.dto.ChatMessage;
import com.example.drawquiz.dto.DrawEvent;
import com.example.drawquiz.dto.SetDrawerRequest;
import com.example.drawquiz.service.GameService;
import java.security.Principal;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class WsGameController {

    private final GameService gameService;
    private final SimpMessagingTemplate broker;

    @MessageMapping("/chat.send")
    public void onChat(ChatMessage msg, Principal p) {
        String sender = (p != null) ? p.getName() : msg.getFrom();
        gameService.handleChat(sender, msg.getText());
    }

    @MessageMapping("/draw.stroke")
    public void onDraw(DrawEvent e, Principal p) {
        if (gameService.canDraw(p)) {
            broker.convertAndSend("/topic/draw", e);
        }
    }

    @MessageMapping("/admin.setDrawer")
    public void onSetDrawer(SetDrawerRequest req, Principal p) {
        if (p == null) return;
        gameService.setDrawerByAdmin(p.getName(), req.getName());
    }
}
