package com.example.drawquiz.controller;

import com.example.drawquiz.service.GameService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class PageController {

    private final GameService gameService;

    @GetMapping("/login")
    public String loginPage() { return "login"; }

    @PostMapping("/login")
    public String doLogin(@RequestParam String name, HttpSession session, Model model) {
        if (!gameService.login(name)) {
            model.addAttribute("error", "허용되지 않은 이름이거나 접속 인원 초과");
            return "login";
        }
        session.setAttribute("name", name);
        return "redirect:/game";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        String name = (String) session.getAttribute("name");
        if (name != null) {
            gameService.logout(name);
        }
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/game")
    public String game(HttpSession session, Model model) {
        String name = (String) session.getAttribute("name");
        if (name == null) return "redirect:/login";
        model.addAttribute("name", name);
        return "game";
    }
}
