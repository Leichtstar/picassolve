package com.example.drawquiz.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ScoreBoardEntry {
    private String name;
    private int score;
}
