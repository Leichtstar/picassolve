package com.example.drawquiz.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class DrawEvent {
    public double x1, y1, x2, y2;
    public double width;
    public String color;
}
