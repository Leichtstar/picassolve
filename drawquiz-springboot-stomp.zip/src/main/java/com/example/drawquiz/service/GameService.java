package com.example.drawquiz.service;

import com.example.drawquiz.domain.UserEntity;
import com.example.drawquiz.domain.UserEntity.Role;
import com.example.drawquiz.domain.WordEntity;
import com.example.drawquiz.repo.UserRepository;
import com.example.drawquiz.repo.WordRepository;
import java.security.Principal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class GameService {
    private final UserRepository userRepo;
    private final WordRepository wordRepo;
    private final SimpMessagingTemplate broker;

    private volatile String currentWord = null;
    private final Object lock = new Object();

    // 현재 접속 중인 사용자 이름(세션 기준)을 추적
    private final Set<String> online = ConcurrentHashMap.newKeySet();

    /** 로그인 처리 */
    @Transactional
    public boolean login(String name) {
        if (!userRepo.existsByName(name)) return false;   // 사전 등록만 허용
        if (online.size() >= 30 && !online.contains(name)) return false; // 30명 제한
        online.add(name);

        // 관리자 지정
        userRepo.findByName(name).ifPresent(u -> {
            if ("송언석".equals(u.getName())) u.setRole(Role.ADMIN);
            else if (u.getRole() == null) u.setRole(Role.PARTICIPANT);
        });

        publishUsersAndScoreboard();
        return true;
    }

    /** 로그아웃 처리 */
    @Transactional
    public void logout(String name) {
        online.remove(name);
        publishUsersAndScoreboard();
    }

    /** 관리자: 특정 유저를 출제자로 지정 */
    @Transactional
    public void setDrawerByAdmin(String adminName, String targetUserName) {
        UserEntity admin = userRepo.findByName(adminName).orElseThrow();
        if (admin.getRole() != Role.ADMIN) throw new RuntimeException("관리자만 가능");

        synchronized (lock) {
            // 기존 출제자 → 참여자
            userRepo.findAll().forEach(u -> {
                if (u.getRole() == Role.DRAWER) u.setRole(Role.PARTICIPANT);
            });
            // 대상 지정
            UserEntity drawer = userRepo.findByName(targetUserName).orElseThrow();
            drawer.setRole(Role.DRAWER);

            // 새 제시어
            currentWord = pickRandomWord();

            // 출제자/관리자에게만 제시어 전송
            broker.convertAndSendToUser(drawer.getName(), "/queue/word", currentWord);
            broker.convertAndSendToUser(admin.getName(), "/queue/word", currentWord);

            publishUsersAndScoreboard();
        }
    }

    /** 채팅/정답 처리 */
    @Transactional
    public void handleChat(String from, String text) {
        broker.convertAndSend("/topic/chat", Map.of("from", from, "text", text, "system", false));

        synchronized (lock) {
            if (currentWord == null) return;
            if (text != null && text.trim().equals(currentWord)) {
                UserEntity winner = userRepo.findByName(from).orElseThrow();
                winner.setScore(winner.getScore() + 1);

                // 이전 출제자 → 참여자
                userRepo.findAll().forEach(u -> {
                    if (u.getRole() == Role.DRAWER) u.setRole(Role.PARTICIPANT);
                });
                // 정답자 → 출제자
                winner.setRole(Role.DRAWER);

                currentWord = pickRandomWord();

                broker.convertAndSend("/topic/chat",
                    Map.of("from","SYSTEM","text", winner.getName()+" 정답! 새 출제자!", "system", true));
                broker.convertAndSend("/topic/canvas/clear", "clear");

                userRepo.findByName("송언석").ifPresent(admin ->
                    broker.convertAndSendToUser(admin.getName(), "/queue/word", currentWord));
                broker.convertAndSendToUser(winner.getName(), "/queue/word", currentWord);

                publishUsersAndScoreboard();
            }
        }
    }

    /** 출제자만 그릴 수 있음 */
    public boolean canDraw(Principal principal) {
        if (principal == null) return false;
        return userRepo.findByName(principal.getName())
                .map(u -> u.getRole() == Role.DRAWER)
                .orElse(false);
    }

    /** 사용자 목록/랭킹 브로드캐스트 */
    private void publishUsersAndScoreboard() {
        // 온라인 사용자만 집계
        List<UserEntity> onlineUsers = online.isEmpty()
                ? List.of()
                : userRepo.findByNameIn(online);

        List<String> users = onlineUsers.stream()
                .map(u -> u.getName() + " (" + u.getRole() + ")")
                .toList();
        broker.convertAndSend("/topic/users", users);

        List<Map<String,Object>> ranking = onlineUsers.stream()
                .sorted(Comparator.comparingInt(UserEntity::getScore).reversed())
                .map(u -> Map.of("name", u.getName(), "score", u.getScore()))
                .collect(Collectors.toList());
        broker.convertAndSend("/topic/scoreboard", ranking);
    }

    private String pickRandomWord() {
        List<WordEntity> all = wordRepo.findAll();
        if (all.isEmpty()) throw new RuntimeException("단어 DB가 비었습니다");
        return all.get(ThreadLocalRandom.current().nextInt(all.size())).getText();
    }
}
