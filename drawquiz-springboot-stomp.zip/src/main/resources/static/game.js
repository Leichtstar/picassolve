(function(){
  const myName = window.MY_NAME || 'guest';

  const socket = new SockJS('/ws');
  const stomp  = Stomp.over(socket);
  stomp.debug = null;

  let isDrawer = false;
  const canvas = document.getElementById('board');
  const ctx    = canvas.getContext('2d', { willReadFrequently: false });
  let drawing = false, prev = null;

  function addChat(line, system=false){
    const div = document.getElementById('chatlog');
    const el = document.createElement('div');
    el.textContent = line;
    if(system) el.classList.add('sys');
    div.appendChild(el);
    div.scrollTop = div.scrollHeight;
  }

  stomp.connect({}, () => {
    stomp.subscribe('/topic/users', msg => {
      const list = JSON.parse(msg.body);
      const ul = document.getElementById('users');
      ul.innerHTML = '';
      list.forEach(t => { const li=document.createElement('li'); li.textContent=t; ul.appendChild(li); });
      isDrawer = list.some(t => t.startsWith(myName+' ') && t.includes('(DRAWER)'));
      document.getElementById('drawRoleHint').textContent = isDrawer ? '지금 당신은 출제자입니다' : '출제자만 그림 가능';
    });

    stomp.subscribe('/topic/scoreboard', msg => {
      const arr = JSON.parse(msg.body);
      const ol = document.getElementById('ranking');
      ol.innerHTML = '';
      arr.forEach(e => { const li=document.createElement('li'); li.textContent=`${e.name} : ${e.score}`; ol.appendChild(li); });
    });

    stomp.subscribe('/topic/chat', msg => {
      const data = JSON.parse(msg.body);
      addChat(`${data.from}: ${data.text}`, !!data.system);
    });

    stomp.subscribe('/topic/draw', msg => {
      const e = JSON.parse(msg.body);
      ctx.strokeStyle = e.color; ctx.lineWidth = e.width; ctx.lineCap='round';
      ctx.beginPath(); ctx.moveTo(e.x1,e.y1); ctx.lineTo(e.x2,e.y2); ctx.stroke();
    });

    stomp.subscribe('/topic/canvas/clear', () => {
      ctx.clearRect(0,0,canvas.width,canvas.height);
    });

    stomp.subscribe('/user/queue/word', msg => {
      const el = document.getElementById('secretWord');
      el.textContent = '제시어 : ' + msg.body;
      el.style.visibility = 'visible';
    });

    addChat('SYSTEM: 연결되었습니다', true);
  });

  document.getElementById('send').onclick = () => {
    const text = document.getElementById('msg').value.trim();
    if(!text) return;
    stomp.send('/app/chat.send', {}, JSON.stringify({from: myName, text}));
    document.getElementById('msg').value = '';
  };

  document.getElementById('btnSetDrawer').onclick = () => {
    const name = document.getElementById('drawerName').value.trim();
    if(name) stomp.send('/app/admin.setDrawer', {}, JSON.stringify({name}));
  };

  // Touch support
  function getPos(e){
    const r = canvas.getBoundingClientRect();
    if(e.touches && e.touches[0]){
      const t = e.touches[0];
      return {x: t.clientX - r.left, y: t.clientY - r.top};
    }
    return {x: e.clientX - r.left, y: e.clientY - r.top};
  }

  canvas.addEventListener('mousedown', e => { if(isDrawer){ drawing=true; prev=getPos(e); }});
  canvas.addEventListener('mouseup',   () => { drawing=false; prev=null; });
  canvas.addEventListener('mouseleave',()=> { drawing=false; prev=null; });
  canvas.addEventListener('mousemove', e => {
    if(!drawing || !isDrawer) return;
    const cur = getPos(e);
    const payload = {
      x1: prev.x, y1: prev.y, x2: cur.x, y2: cur.y,
      width: +document.getElementById('width').value,
      color: document.getElementById('color').value
    };
    stomp.send('/app/draw.stroke', {}, JSON.stringify(payload));
    prev = cur;
  });

  // Touch events
  canvas.addEventListener('touchstart', e => { if(isDrawer){ drawing=true; prev=getPos(e); }});
  canvas.addEventListener('touchend',   () => { drawing=false; prev=null; });
  canvas.addEventListener('touchmove', e => {
    if(!drawing || !isDrawer) return;
    const cur = getPos(e);
    const payload = {
      x1: prev.x, y1: prev.y, x2: cur.x, y2: cur.y,
      width: +document.getElementById('width').value,
      color: document.getElementById('color').value
    };
    stomp.send('/app/draw.stroke', {}, JSON.stringify(payload));
    prev = cur;
    e.preventDefault();
  }, {passive:false});

})();
