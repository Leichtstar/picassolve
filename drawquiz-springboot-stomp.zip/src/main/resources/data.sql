INSERT INTO users(name, score, role) VALUES ('송언석', 0, 'ADMIN');
INSERT INTO users(name, score, role) VALUES ('김하나', 0, 'PARTICIPANT');
INSERT INTO users(name, score, role) VALUES ('이둘',   0, 'PARTICIPANT');
INSERT INTO users(name, score, role) VALUES ('박셋',   0, 'PARTICIPANT');

INSERT INTO words(text) VALUES ('사과');
INSERT INTO words(text) VALUES ('기차');
INSERT INTO words(text) VALUES ('컴퓨터');
INSERT INTO words(text) VALUES ('토끼');
INSERT INTO words(text) VALUES ('축구');
